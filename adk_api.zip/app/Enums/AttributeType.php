<?php

namespace App\Enums;

interface UnitType
{
    const SIZE = 'size';

    const WEIGHT = 'weight';

    const QUANTITY = 'quantity';
}
